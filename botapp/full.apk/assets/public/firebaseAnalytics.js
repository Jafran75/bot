// // Import the functions you need from the SDKs you need
// import { initializeApp } from "firebase/app";
// import { getAnalytics } from "firebase/analytics";
// // TODO: Add SDKs for Firebase products that you want to use
// // https://firebase.google.com/docs/web/setup#available-libraries

// // Your web app's Firebase configuration
// // For Firebase JS SDK v7.20.0 and later, measurementId is optional
// const firebaseConfig = {
//   apiKey: "AIzaSyC6cnzV2iKuhUxcyjH2L4pvKR0Tv1iTIXg",
//   authDomain: "test1-7ffe6.firebaseapp.com",
//   projectId: "test1-7ffe6",
//   storageBucket: "test1-7ffe6.firebasestorage.app",
//   messagingSenderId: "846418415347",
//   appId: "1:846418415347:web:5ab6d20e9772cb67617186",
//   measurementId: "G-VM62FXQ912"
// };

// // Initialize Firebase
// const app = initializeApp(firebaseConfig);
// const analytics = getAnalytics(app);